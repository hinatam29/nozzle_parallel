
      program main
      include 'subcom.inc'
c     --- 途中からの再開用（restart.f）---
      integer*8 iseed
      logical lrst
      logical lpot

c     各周期で注入する2ステップ(ノズルごと1回)。-1で初期化=最初の周期まで不注入
      data ns1, ns2 /-1, -1/

      gam = 1.402

c     dt = 5.0e-11
c     dt = 1.0e-10
c     dt = 2.0e-9
c     dt = 1.0e-8
c     dt = 1.0e-6
c     dt = 5.0e-7
      dt = 2.0e-7
      ftime = 11.e-3
c     ftime = 1.e2
      otime = 2.5e-2
      dtime = 1.e-2

      etime = 1.e-6

      pi = 4.0*atan(1.0)

      Re = 1000.

      gv = 9.8
c     gv = 0.

c     fss = 1. / ( 70.e3 )
c     fss = 70.e3
c     fss = fss/dt
c     fss = 3.
      fss = 7.
c     fss = 17.
c     fss = 14.
c     fss = 47.

c     write(*,*) fss

c     ipmx = 500.
c     ipmx = 2000.
      ipmx = 100000.
c     v3: 最初は左のノズルの 3 個（＋鏡像 2 個）が出た状態から始める
      ip = 3

c     rhol = 797.88 
      rhol = 1027.
      rhog = 1.25

c     xmul = 0.8544e-3
c     xmul = 50e-3
      xmul = 10e-3
c     xmul = 85.44e-3
c     xmul = 128e-3
      xmug = 1.862e-5

c     svl = sqrt(1.18e8/789.)
      svl = 1500.
      svg = sqrt(1.402*287.*300.)

      sigl = 0.277
c     sigl = 100.e-6
      sigg = 2.5e-10 

c     vxmax = 0.
c     vymax = 0.


      TVB = 0. 
c     TEC = 1. 
      TEC = 0.95 
     

      iend = int(ftime/dt)
c     iend = 212505
      iout = int(otime/dt)
c     idata = int(dtime/dt)
c     idata = 1
c     idata = 10
c     idata = 100
      idata = 1000
      ikzoku = 500

      ielec = int(etime/dt)

      time = 0.
      istp = 1

c     --- 途中から再開するか（restart.dat があれば続きから計算する）---
c     最初から計算し直すときは restart.dat を消してから実行する
      iseed = 20261014
      nrst = 1000
      inquire(file='./restart.dat', exist=lrst)
      lpot = .false.

      if( lrst )then
c       続きを今までのファイルの後ろに追記する
        open(100,file='./flow.dat',status='unknown',blank='null',
     &       position='append')
        open(300,file='./spray.dat',status='unknown',blank='null',
     &       position='append')
      else
        open(100,file='./flow.dat',status='unknown',blank='null')
        open(300,file='./spray.dat',status='unknown',blank='null')
        write(300,*) ' title = " SPRAY " '
        write(300,*) ' variables= "xp","yp","dp","clt","pout" '
        write(100,*) ' title = " FLOW FIELD  " '
        write(100,*) ' variables= "x","y","phi","cvolume","cgg"'
      end if
c     kzoku.dat（古い流体計算用の保存ファイル、数百MB）は使わないので書かない
c     open(200,file='./kzoku.dat',status='unknown',blank='null')
c     write(100,*) ' variables= "xp","yp","phi","cgg"'

c     iend = 10
c     iout = 1

      call geo

      call rancal
      call initial

      if( lrst )then
        call rrestart(iseed, ns1, ns2)
        write(*,*) 'RESTART from istp=', istp, ' time=', time,
     &             ' ip=', ip
      end if

c     open(300,file='./cont.dat',status='old')
c     call kinput

c     call bound1

 100   continue

c     call dfunc
c     call prop

c100   continue
c     call advect
c     call advVOF
c     call dfunc
c     call heviside
c     end if
c     call pfield_bicg
c     call proj

c     call dfunc
c     if( istp .eq. 1 .or. mod(real(istp),1000.) .eq. 0. ) then
c     call heviside
c     end if
c     call prop

c     call psearch
c     call diffusion
c     call difrho
      call viscous
c     call grav
c     call csf

c     irep = 1
110   continue
c     if( istp .eq. 1 .or. mod(real(istp),20.) .eq. 0. ) then
c     if( irep .le. 10 ) then
c     --- 修正(2026-10-16): 電位はラプラス方程式（液滴の電荷を含まない）で
c     毎ステップ同じ解になるので、最初の1回だけ厳しく解く（再開時も1回）---
      if( .not. lpot ) then
      call potential
      call ej
      lpot = .true.
      end if
c     call charge
c     end if
c     call elec
c     irep = irep + 1
c     go to 110
c     end if

c     write(*,*) ip
      call eforce

      if( ip .eq. 1. ) then
      go to 130
      end if

      call intraction

 130  continue

      call pcount

      call diffusion_liq
      call diffusion_gas
      call diffusion1
      


c     if( istp .eq. 1 .or. mod(real(istp),real(ikzoku)) .eq. 0. ) then
c        call kzoku
c     end if

      write(*,*) istp,time,ip,ctotal
      if( istp .eq. 1 .or. mod(real(istp),real(idata)) .eq. 0. ) then
c     write(*,*) istp, time  
c     if( istp .eq. iend ) then
c     if( time .eq. ftime ) then
c     write(100,*) 'zone t="n= ',istp,'", i=',nx-3,',j=',ny-3,',f=point'
c     --- 2026-10-31: flow.dat（電位はほぼ変わらない）は最初と 11000 ステップごとだけ書く
c     （ディスク節約。visualize.py は最初のコマしか使わない）---
      if( istp .eq. 1 .or. mod(istp,11000) .eq. 0 )then
      write(100,*) 'zone t="n= ',istp,'", i=',nx-1,',j=',ny-1,',f=point'
c     write(100,*) 'zone t="n= ',istp,'", f=point'
         do 150 j=1, ny-1
         do 160 i=1, nx-1
         xx = 0.5*(x(i,j)+x(i+1,j))
         yy = 0.5*(y(i,j)+y(i,j+1))
         ij = jj(i,j)         

         Etotal(ij) = sqrt( (Er(ij)*Er(ij)+Ez(ij)*Ez(ij)) )

c        write(100,1000) xx, yy, vf0(i,j), ux0(i,j), uy0(i,j), p0(i,j),
c    &                   dphi(i,j),fsvx(i,j),fsvy(i,j),phi(ij),
c    &                   dphi(i,j),gradx(i,j),grady(i,j),phi(ij),
c    &                   Er(ij),Ez(ij),rhoc0(i,j),fer(ij),fez(ij) 
c        write(100,*) xx, yy, vf0(i,j)
c        write(100,*) xx, yy, p0(i,j)
         write(100,1000) xx, yy, phi(ij), cvolume(i,j), cgg(i,j)
c        write(100,1000) xx, yy, phi(ij),Er(ij),Ez(ij),
c    &                   Etotal(ij),cg(i,j)
c        write(100,*) xx, yy, phi(ij),Etotal(ij),cg(i,j)
c    &                   Ernex(ij), Eznex(ij) 
 160      continue
c        write(100,*)
 150      continue
      end if

c        --- spray (particle) output for visualization ---
         write(300,*) 'zone t="n= ',istp,'", i=',ip,',f=point'
         do 170 k=1, ip
         write(300,1000) xp(k), yp(k), dp(k), clt(k), pout(k)
 170      continue

c        --- 各出力ごとにディスクへ確実に書き出す ---
c        （途中で止めても完成フレームがファイルに残る）
         call flush(100)
         call flush(300)

1000  format(15E20.8)
      end if

c     vxmax = 0.
c     vymax = 0.

c     ux = 0.
c     uy = 0.
c     cfl = 0.3
c     if( mod(real(istp),100.) .eq. 0. ) then

c     do 200  i=1, nx
c     do 200  j=1, ny

c     ux = sqrt(ux_sx(i,j)*ux_sx(i,j)+
c    &          ux_sy(i,j)*ux_sy(i,j))
       
c     uy = sqrt(uy_sx(i,j)*uy_sx(i,j)+
c    &          uy_sy(i,j)*uy_sy(i,j))
      
c     ux = ux_sx(i,j)
c     uy = uy_sy(i,j)
      
c     uxsdx = ux/sdx(i,j)
c     uysdy = uy/sdy(i,j) 

c     if( vxmax .lt. uxsdx) then
c     vxmax = uxsdx
c     end if
      
c     if( vymax .lt. uysdy) then
c     vymax = uysdy
c     end if
c00   continue

c     dt = min( cfl/vxmax, cfl/vymax)
c     if( dt .gt. 1.e-6) dt = 1.e-6
        
c     end if

c     write(*,*) real(istp), fss

c     --- 液滴の注入：各ノズルとも fss ステップの窓の中で1回、ランダムな
c     ステップで注入する。初期設定(initial.f)で 奇数k=ノズル1, 偶数k=ノズル2。
c     ipが1増えるごとに次の粒子(=交互に別ノズル)が有効化されるので、1周期に
c     ちょうど2回(=各ノズル1個)有効化する。2ステップは相異なる値を選び、
c     両ノズルが同時刻に噴霧しないようにする（窓内でランダムに揺らぐ）。
      iph = int( mod(real(istp),real(fss)) )
      if( iph .eq. 0 )then
         ns1 = int( prand(iseed)*fss )
         if( ns1 .ge. int(fss) ) ns1 = int(fss) - 1
 210     ns2 = int( prand(iseed)*fss )
         if( ns2 .ge. int(fss) ) ns2 = int(fss) - 1
         if( ns2 .eq. ns1 ) go to 210
      end if

c     --- v3 (2026-10-22): 1回に 3 個（＋鏡像 2 個 ＝ 5 個）を同時に出す ---
      if( ip .lt. ipmx-6 )then
         if( iph .eq. ns1 ) ip = ip + 3
         if( iph .eq. ns2 ) ip = ip + 3
      end if

 200  continue

      if( istp .le. iend ) then
      time = time + dt
      istp = istp + 1
c     nrst ステップごとに、次のステップから再開できる状態を保存する
      if( mod(istp-1, nrst) .eq. 0 ) call wrestart(iseed, ns1, ns2)
      go to 100
      end if

 
      stop
      end      
